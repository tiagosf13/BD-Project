function redirectProfile(username) {
    // Redirect to the login page
    window.location.href = `/profile/${username}`;
}